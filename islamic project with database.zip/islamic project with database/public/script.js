$(document).ready(function () {
    $(".video").hide(); // Hide all videos at the start

    $(".btn").on("click", function () {
        let buttonId = $(this).attr("id"); // Get button ID (e.g., "num1")
        let videoId = "#" + buttonId + "-video"; // Find matching iframe ID (e.g., "#num1-video")

        if (!$(videoId).hasClass("loaded")) {
            let videoUrl = $(videoId).attr("data-src"); // Get video URL from data-src
            $(videoId).attr("src", videoUrl).addClass("loaded"); // Load video
        }
        $(videoId).toggle(); // Show/hide video
    });
});



/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }
  
  // Close the dropdown if the user clicks outside of it
  window.onclick = function(e) {
    if (!e.target.matches('.dropbtn')) {
    var myDropdown = document.getElementById("myDropdown");
      if (myDropdown.classList.contains('show')) {
        myDropdown.classList.remove('show');
      }
    }
  }
