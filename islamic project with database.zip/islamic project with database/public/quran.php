<?php
$servername = "sql113.infinityfree.com";
$username = "if0_38557014";
$password = "6WFXGc3q8bf";
$dbname = "if0_38557014_quran";

// connect to the database 
$conn = new mysqli($servername, $username, $password, $dbname);

// if can not connect 
if ($conn->connect_error) {
    die("کۆنێکت ناکرێت: " . $conn->connect_error);
}

// search bar 
$search = isset($_GET['search']) ? $_GET['search'] : '';

if (!empty($search)) {
    // `$search` پاکبکەوە بۆ هەڵگیری لە SQL Injection
    $search = $conn->real_escape_string($search);
    $sql = "SELECT * FROM quran WHERE video_name COLLATE utf8mb4_general_ci LIKE '%$search%'";
} else {
    // ئەگەر `$search` بەتاڵ بێت، هیچ بەرزێک مەهێنە
    $sql = "SELECT * FROM quran WHERE 1 = 0";
}

$result = $conn->query($sql);

// ئەگەر `$result` null بێت، هەڵەی `SQL` چالاک بکە
if (!$result) {
    die("Error in SQL Query: " . $conn->error);
}

// چاوپێکەوتن بە `$result`
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<p>Search Query: " . htmlspecialchars($search) . "</p>";
        echo "<iframe width='560' height='315' src='" . htmlspecialchars($row["video_url"]) . "' frameborder='0' allowfullscreen></iframe>";
        echo "</div><br>";
    }
} else {
    echo "<p style='color:red; text-align:center;'>هیچ ئەنجامێک نەدۆزرایەوە</p>";
}

$conn->close();
?>